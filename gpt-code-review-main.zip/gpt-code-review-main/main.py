import tiktoken

from helpers.config import (
    COMMIT_REF_NAME,
    FF_DISABLE_BLACKLIST_VALIDATION,
    FF_UPDATE_MR_DESCRIPTION,
    MERGE_REQUEST_IID,
    OPENAI_MODEL,
    OPENAI_MODEL_MAX_TOKENS,
    PROJECT_ID,
    PROJECT_NAME,
    PROMPT,
)
from helpers.gitlab import (
    get_mr,
    get_mr_comment_id_using_text,
    get_mr_diff,
    post_mr_comment,
    update_mr_description,
)
from helpers.messaging import CodeReviewMessage, send_message
from helpers.openai import call_openai_complete, get_playground_link
from helpers.prompt import get_additional_prompt, load_prompt_from_file
from helpers.validate import is_blacklisted_branch

ENCODING = tiktoken.encoding_for_model(OPENAI_MODEL)

# Metrics
EXPECTED_TOKEN_USAGE = 0
TOTAL_TOKENS_USED = 0
OPENAI_CALLS_DONE = 0


# tiktoken-related code
def count_tokens(text):
    num_tokens = len(ENCODING.encode(text))
    return num_tokens


def get_prompt(code, review_text):
    prompt = (
        f"Here are some code changes in git diff format:\n{code}" f"\n\n{review_text}"
    )
    return prompt


# Summarize and review code using OpenAI API
def review_code(code, review_text):
    global TOTAL_TOKENS_USED
    global OPENAI_CALLS_DONE
    message_array = get_prompt(code, review_text)
    [review_text, tokens_used, openai_calls_done] = call_openai_complete(message_array)
    TOTAL_TOKENS_USED += tokens_used
    OPENAI_CALLS_DONE += openai_calls_done
    return review_text


def playground_link(code, review_text):
    global TOTAL_TOKENS_USED
    global OPENAI_CALLS_DONE
    message_array = get_prompt(code, review_text)
    playground_link = get_playground_link(message_array)
    return playground_link


def main():
    global EXPECTED_TOKEN_USAGE
    global TOTAL_TOKENS_USED
    global OPENAI_CALLS_DONE
    review_prompt = PROMPT if PROMPT else load_prompt_from_file("whole-diff.md")
    mr_details = get_mr(PROJECT_ID, MERGE_REQUEST_IID)
    additional_prompt = get_additional_prompt(mr_details.description)

    if additional_prompt:
        review_prompt = review_prompt + "\n\n" + additional_prompt

    diff = get_mr_diff(PROJECT_ID, MERGE_REQUEST_IID)
    changes = diff["changes"]
    all_reviews = []
    skipped_files = []

    token_count = 0
    batch_diffs = []
    extra_token_in_prompt = count_tokens(get_prompt("", review_prompt))

    final_review = ""

    for change in changes:
        current_diff = change["diff"]  # Extract only the diff text
        current_token_count = count_tokens(current_diff)

        if current_token_count + extra_token_in_prompt > OPENAI_MODEL_MAX_TOKENS:
            skipped_files.append(change["new_path"])
            continue

        if (
            token_count + current_token_count + extra_token_in_prompt
            > OPENAI_MODEL_MAX_TOKENS
        ):
            EXPECTED_TOKEN_USAGE += token_count + extra_token_in_prompt
            batch_reviews = review_code("\n".join(batch_diffs), review_prompt)
            all_reviews.append(f"\n\n{batch_reviews}")

            batch_diffs = [current_diff]
            token_count = current_token_count
        else:
            batch_diffs.append(current_diff)
            token_count += current_token_count

    if batch_diffs:
        EXPECTED_TOKEN_USAGE += token_count + extra_token_in_prompt
        batch_reviews = review_code("\n".join(batch_diffs), review_prompt)
        all_reviews.append(f"\n\n{batch_reviews}")

    if len(all_reviews) > 1:
        # Consolidate summaries and perform a final review call only if there are multiple summaries
        consolidated_summary = "\n\n".join(
            f"Summary {i + 1}: {review}" for i, review in enumerate(all_reviews)
        )
        consolidated_summary_prompt = "Consolidate all these into a single summary. Feel free to correlate between them."  # noqa
        final_review = review_code(consolidated_summary, consolidated_summary_prompt)

        EXPECTED_TOKEN_USAGE += count_tokens(consolidated_summary) + count_tokens(
            consolidated_summary_prompt
        )
        comment = (
            f"OpenAI Summary and Code Review:\n\n{final_review}\n\nConsolidated Summary per batch of files:"
            + consolidated_summary
        )
    else:
        comment = "OpenAI Summary and Code Review:\n\n" + all_reviews[0]  # noqa

    if skipped_files:
        comment += "\n\nSkipped files due to token limit exceeded:" + "\n".join(
            skipped_files
        )

    pg_link = playground_link("\n".join(batch_diffs), review_prompt)

    if FF_UPDATE_MR_DESCRIPTION:
        [updated_mr_description, tokens_used, openai_calls_done] = call_openai_complete(
            "Based on this "
            + comment
            + "Using only the summary of changes write the Merge Request description by strictly following the given format without removing the details:"  # noqa
            + mr_details.description
            + "Ignore the unknown fields.",
            retries=1,
            sleep_time=0,
        )
        try:
            print(f"Updated MR description: {updated_mr_description}")
            update_mr_description(PROJECT_ID, MERGE_REQUEST_IID, updated_mr_description)
            TOTAL_TOKENS_USED += tokens_used
            OPENAI_CALLS_DONE += openai_calls_done
        except Exception as e:
            print(f"Failed to update MR description. Error: {e}")

    comment += (
        f"\n\nModel used: {OPENAI_MODEL}"
        + f"\n\nOpenAI calls made: {OPENAI_CALLS_DONE}"
        + f"\n\nTotal tokens used: {TOTAL_TOKENS_USED}"
        + f"\n\nExpected token usage: {EXPECTED_TOKEN_USAGE}"
        + "\n\n-----"
        + "\n\n### Think the this review can be improved?"
        + "\n\n_If you want to improve the review you can always update the prompts in the code base and see the changes in the next review."  # noqa
        + " See [here](https://data-experience.pages.agodadev.io/gpt-code-review/configuring_review_prompt.html) for more details._"  # noqa
        + f"\n\nHere's the [GPT Playground link]({pg_link}) for this review if you want to try different prompts or parameters."  # noqa
    )

    comment_id = get_mr_comment_id_using_text(
        PROJECT_ID, MERGE_REQUEST_IID, "OpenAI Summary and Code Review:"
    )

    post_mr_comment(PROJECT_ID, MERGE_REQUEST_IID, comment, comment_id)

    try:
        send_message(
            CodeReviewMessage(
                gitlab_project_id=PROJECT_ID,
                gitlab_project_name=PROJECT_NAME,
                gitlab_project_branch=COMMIT_REF_NAME,
                gitlab_merge_request_iid=MERGE_REQUEST_IID,
                openai_model=OPENAI_MODEL,
                token_usage=TOTAL_TOKENS_USED,
                note_id=comment_id,
                review_type="whole-diff",
            )
        )
    except Exception as e:
        print(f"Failed to send message to hadoop. Error: {e}")


if __name__ == "__main__":
    if not FF_DISABLE_BLACKLIST_VALIDATION and is_blacklisted_branch():
        print("Skipping review for blacklisted branch")
    else:
        main()
