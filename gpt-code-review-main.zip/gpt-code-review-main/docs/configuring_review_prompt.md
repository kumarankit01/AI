# Configuring Review Prompt

The GPT Code Review pipeline utilizes the prompt specified in the `.prompts/whole-diff.md` or `.prompts/file-based.md` files from [.prompts](https://gitlab.agodadev.io/data-experience/gpt-code-review/-/tree/main/.prompts) directory of this repository by default.

### Override default prompt at the repository level:

To tailor the code review functionality according to your requirements, you can override the default prompts by placing your own `.prompts/whole-diff.md` or `.prompts/file-based.md` file in your repository.


> [!CAUTION]
> This will override the default prompts so incase you want to append something to existing prompt you can copy over the contents from respective file under [default prompts](https://gitlab.agodadev.io/data-experience/gpt-code-review/-/tree/main/.prompts) and append your prompt to it.


### Append to prompt at the MR level:

Additionally, we also offer an option to use an additional prompt specific to your merge request (MR). To use additional prompt for GPT's code review to give more context to GPT, follow the steps below:

1. In your MR description, insert the additional prompt wrapped within a markdown code block, like so:

````markdown
```prompt
    <your-additional-prompt-for-this-MR>
```
````

By following this methodology, GPT will use the additional prompt provided in the MR description conjunction with the existing prompt. This could be particularly useful when the review requirements vary across different MRs.

> [!CAUTION]
> Ensure that the additional prompt is clear and specific, as it can significantly impact the effectiveness of the GPT Code Review.
