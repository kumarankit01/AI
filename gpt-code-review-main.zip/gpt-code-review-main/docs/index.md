# GPT Code Review

### Introduction

- GPT Code Review is a tool that can leverage OpenAI APIs to help you review code changes.
- Currently, it provides two variations of code review:
  - **Whole Diff Code Review:** This is a code review that is based on the diff of the whole merge request.
  - **File Based Code Review:** This is a code review that is based on the diff of the files in the merge request.
