# Manual Setup

<br/>
Welcome to the configuration guide for GPT Code Review. This configuration allows you to utilize GPT for reviewing your code.

<br/>
<br/>

### Prerequisites

Before proceeding, ensure the following environment variables are set in your repository:

1. `GITLAB_API_TOKEN` : Create a token with read and write permissions to allow access to your repository and to comment on MRs

_Optional:_
2. `OPENAI_MODEL` : By default, this is set to `gpt-4-1106-preview` which is the latest version of the model. You can change this to any other version of the model that you want to use.

<br/>

### Configuration Steps

To set up the GPT Code Review pipeline in your project's GitLab CI/CD, carry out the following steps:

<br/>

#### Step 1: Include the GPT Code Review Template

In your project's `gitlab-ci.yml` file, include the GPT Code Review template:

```yaml
include:
  - project: "data-experience/gpt-code-review"
    ref: main
    file:
      - "/ci-template/gpt-code-review.gitlab-ci.yml"
```

<br/>

#### Step 2: Configure the job for GPT Code Review

Under the jobs section, configure a new job for GPT Code Review as follows:

> [!NOTE]
> We suggest you not to override the `rules` section as it is already configured to run only on merge requests and set to trigger manually. However, if you wish to override it, you can do so by setting the `rules` section in your job.

```yaml
GPT Code Review:
  stage: <review-stage>
  extends: .gpt-code-review
  variables:
    FF_UPDATE_MR_DESCRIPTION: "true" # Optional by default it is false
    INCLUDE_FILE_EXTENSIONS: ".+\.cs$,.+\.tsx$" # Optional by default it is None
```

<br/>

You can use file based code review as follows: **(Still in beta)**

```yaml
GPT File Based Review:
  stage: <review-stage>
  extends: .gpt-file-based-review
  variables:
    FF_UPDATE_MR_DESCRIPTION: "true" # Optional by default it is false
    INCLUDE_FILE_EXTENSIONS: ".+\.cs$,.+\.tsx$" # Optional by default it is None
```

Please note that the Review Stage(review-stage) can be any stage name you set in your pipeline. For example, if your pipeline stages are 'build', 'test' and 'deploy', you might want to utilize 'test' as your review-stage.

### Add code review results to MR description automatically:

> [!NOTE]
> Your GITLAB_API_TOKEN should have 'developer' or 'reporter' access to your repository.

By default, the GPT Code Review pipeline will not update the MR description with the code review. However, if you wish to enable this functionality, you can do so by setting the `FF_UPDATE_MR_DESCRIPTION` variable to `true` in your project's `gitlab-ci.yml` file, like so:

```yaml
variables:
  FF_UPDATE_MR_DESCRIPTION: "true"
```

### Specify which files will be reviewed:

By default, GPT Code Review will review all files in the changes. However, if you want GPT to only review certain files that are in the changes, you can do so by setting the `INCLUDE_FILE_EXTENSIONS` variable to a list of file regex(s) (in comma-separated string format) in your project's `gitlab-ci.yml` file, like so:

```yaml
variables:
  INCLUDE_FILE_EXTENSIONS: ".+\.cs$,.+\.tsx$"
```

### Opt-out review summary:

In File Based Code Review, by default GPT Code Review will also post a summary of review results as an MR note. However, if you want to opt-out of this functionality, you can do so by setting the `FF_SKIP_SUMMARY` variable to `true` in your project's `gitlab-ci.yml` file, like so:

```yaml
variables:
  FF_SKIP_SUMMARY: "true"
```

Note that this only applies to File Based Code Review.
