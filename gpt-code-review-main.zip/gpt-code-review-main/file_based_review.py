import asyncio
import random
import re
import time

import tiktoken

from helpers.config import (
    COMMIT_REF_NAME,
    COMMIT_SHA,
    FF_DISABLE_BLACKLIST_VALIDATION,
    FF_SKIP_SUMMARY,
    FF_UPDATE_MR_DESCRIPTION,
    MERGE_REQUEST_IID,
    OPENAI_MODEL,
    OPENAI_MODEL_MAX_TOKENS,
    PROJECT_ID,
    PROJECT_NAME,
    PROMPT,
)
from helpers.diff import parse_unified_diff
from helpers.file_based_prompt import (
    get_prompt_final_summary,
    get_prompt_group_file_summaries,
    get_prompt_summary_per_file,
)
from helpers.gitlab import (
    get_diff_from_specific_commit,
    get_file_content,
    get_mr,
    get_mr_comment_body_using_text,
    get_mr_comment_id_using_text,
    get_mr_diff,
    post_mr_comment,
    post_mr_comment_in_position,
    update_comment_to_unresolved,
    update_mr_description,
)
from helpers.messaging import CodeReviewMessage, send_message
from helpers.openai import call_openai_complete, get_playground_link
from helpers.prompt import get_additional_prompt, load_prompt_from_file
from helpers.validate import is_blacklisted_branch

ENCODING = tiktoken.encoding_for_model(OPENAI_MODEL)

# Metrics
TOTAL_TOKENS_USED = 0
OPENAI_CALLS_DONE = 0

# Constant
BATCH_SIZE_FILE_SUMMARIZE = 10
ERROR_REVIEW_FLAG = "ERROR_REVIEW"
ERROR_SUMMARY_FLAG = "ERROR_SUMMARY"
TAG_MR_COMMENT = "OpenAI File Based Summary and Code Review"
TAG_REVIEW_COMMENT = "#### File Review for"
LGTM_COMMENTS = ["lgtm", "- lgtm"]


# Get Override prompt from MR description it's a code block with the following format:
# ```prompt
# <prompt>
# ```
def get_override_prompt(description):
    matches = re.findall(r"```prompt(.*?)```", description, re.DOTALL)

    if matches:
        return matches[0].strip()
    else:
        return ""


# tiktoken-related code
def count_tokens(text):
    num_tokens = len(ENCODING.encode(text))
    return num_tokens


def get_prompt(content, diff, review_prompt):
    prompt = f"""#File Content:\n\n```\n{content}```\n\n
#Changes in Git Diff Format:\n\n```\n{diff}\n```\n\n{review_prompt}"""

    return prompt


# Helper function to call OpenAI and handle tokens
async def call_openai(prompt):
    global TOTAL_TOKENS_USED
    global OPENAI_CALLS_DONE
    [review_text, tokens_used, openai_calls_done] = call_openai_complete(prompt)
    TOTAL_TOKENS_USED += tokens_used
    OPENAI_CALLS_DONE += openai_calls_done
    return review_text


# Summarize and review code using OpenAI API
async def review_code_async(file_path, content, diff, review_prompt):
    prompt = get_prompt(content, diff, review_prompt)

    try:
        review_text = await call_openai(prompt)
    except Exception as e:
        print(f"Failed to review code for File Path: {file_path}. Error: {e}")
        review_text = ERROR_REVIEW_FLAG

    return {"file_path": file_path, "prompt": prompt, "review_text": review_text}


# Summarize file
async def file_summary_async(file_path, summary_prompt):
    try:
        review_text = await call_openai(summary_prompt)
    except Exception as e:
        print(f"Failed to summariez for File Path: {file_path}. Error: {e}")
        review_text = ERROR_SUMMARY_FLAG
    return {"file_path": file_path, "review_text": review_text}


async def summary_diffs(changes):
    skipped_files = []
    failed_files = []
    tasks = []

    for change in changes:
        new_path = change["new_path"]
        current_file_path = new_path
        current_diff = change["diff"]

        if is_deleted_file(change):
            skipped_files.append(current_file_path)
            continue

        try:
            current_content = get_file_content(
                PROJECT_ID, current_file_path, COMMIT_REF_NAME
            )
        except Exception as e:
            print(
                f"Failed to get file content for File Path: {current_file_path}. Error: {e}"
            )
            failed_files.append(current_file_path)
            continue

        summary_prompt = get_prompt_summary_per_file().format(
            diff=current_diff, file_content=current_content
        )

        current_token_count = count_tokens(summary_prompt)

        if current_token_count > OPENAI_MODEL_MAX_TOKENS:
            skipped_files.append(current_file_path)

        task = asyncio.create_task(
            file_summary_async(current_file_path, summary_prompt)
        )
        tasks.append(task)

    all_summaries = await asyncio.gather(*tasks)

    print(
        f"Total summaries: {len(all_summaries)} and skipped files: {len(skipped_files)}"
    )
    raw_summary = ""
    final_summary = ""
    if len(all_summaries) > 0:
        for i in range(0, len(all_summaries), BATCH_SIZE_FILE_SUMMARIZE):
            batch_summaries = all_summaries[i : i + BATCH_SIZE_FILE_SUMMARIZE]
            current_summary = ""
            for summary in batch_summaries:
                if summary == ERROR_SUMMARY_FLAG:
                    failed_files.append(summary["file_path"])
                    continue

                current_summary += f"""---
                {summary['file_path']}: {summary['review_text']}
                """

            summary_prompt = get_prompt_group_file_summaries().format(
                raw_summary=(raw_summary + current_summary)
            )

            if count_tokens(summary_prompt) > OPENAI_MODEL_MAX_TOKENS:
                print("Token limit exceeded. Stopping summarization.")
                break

            try:
                raw_summary = await call_openai(summary_prompt)
            except Exception as e:
                print(f"Failed to group file summaries. Error: {e}")

        try:
            final_summary_prompt = get_prompt_final_summary().format(
                raw_summary=raw_summary
            )
            final_summary = await call_openai(final_summary_prompt)
        except Exception as e:
            print(f"Failed to create final summary. Error: {e}")

    if skipped_files:
        print("Skipped files due to token limit exceeded: " + "\n".join(skipped_files))
    if failed_files:
        print("Failed to review files: " + "\n".join(failed_files))

    return final_summary


async def process_diffs(diff_refs, changes, review_prompt):
    skipped_files = []
    failed_files = []
    lgtm_files = []
    tasks = []
    extra_token_in_prompt = count_tokens(get_prompt("", "", review_prompt))

    print(f"Extra token in prompt: {extra_token_in_prompt}")
    for change in changes:
        new_path = change["new_path"]
        current_file_path = new_path
        current_diff = change["diff"]

        if is_deleted_file(change):
            skipped_files.append(current_file_path)
            continue

        try:
            current_content = get_file_content(
                PROJECT_ID, current_file_path, COMMIT_REF_NAME
            )
        except Exception as e:
            print(
                f"Failed to get file content for File Path: {current_file_path}. Error: {e}"
            )
            failed_files.append(current_file_path)
            continue

        current_token_count = count_tokens(current_diff + current_content)

        if current_token_count + extra_token_in_prompt > OPENAI_MODEL_MAX_TOKENS:
            skipped_files.append(current_file_path)
            continue

        print(f"Current file path: {current_file_path}")

        task = asyncio.create_task(
            review_code_async(new_path, current_content, current_diff, review_prompt)
        )
        tasks.append(task)

    all_reviews = await asyncio.gather(*tasks)

    print(f"Total reviews: {len(all_reviews)} and skipped files: {len(skipped_files)}")

    for change in changes:
        current_file_path = change["new_path"]
        print(f"Current file path: {current_file_path}")

        if current_file_path not in skipped_files:
            review_text = ERROR_REVIEW_FLAG
            for review in all_reviews:
                if review["file_path"] == current_file_path:
                    review_text = review["review_text"]

            if review_text == ERROR_REVIEW_FLAG:
                failed_files.append(current_file_path)
                continue

            if review_text.lower() in LGTM_COMMENTS:
                lgtm_files.append(current_file_path)
                continue

            try:
                post_comment_review(diff_refs, change, review_text)
            except Exception as e:
                print(
                    f"Failed to post comment for File Path: {current_file_path}. Error: {e}"
                )
                failed_files.append(current_file_path)

    if skipped_files:
        print("Skipped files due to token limit exceeded: " + "\n".join(skipped_files))
    if failed_files:
        print("Failed to review files: " + "\n".join(failed_files))
    if lgtm_files:
        print("LGTM files: " + "\n".join(lgtm_files))

    return [review["prompt"] for review in all_reviews]


def post_comment_review(diff_refs, mr_change, review_text):
    current_file_path = mr_change["new_path"]

    parsed_diffs = parse_unified_diff(mr_change["diff"])
    first_chunk = parsed_diffs[0]
    post_mr_comment_to_line = {
        "old_line": first_chunk["old_line"]
        if first_chunk["status"] == "removed"
        else None,
        "new_line": first_chunk["new_line"],
    }

    comment_id = get_mr_comment_id_using_text(
        PROJECT_ID,
        MERGE_REQUEST_IID,
        f"{TAG_REVIEW_COMMENT} {current_file_path}",
    )

    comment = f"{TAG_REVIEW_COMMENT} {current_file_path}\n\n{review_text}"
    if comment_id:
        call_gitlab_with_retry(
            post_mr_comment,
            (PROJECT_ID, MERGE_REQUEST_IID, comment, comment_id),
            {},
        )
        call_gitlab_with_retry(
            update_comment_to_unresolved,
            (PROJECT_ID, MERGE_REQUEST_IID, comment_id),
            {},
        )
        send_message_hadoop(comment_id)
    else:
        position = {
            "new_path": current_file_path,
            "old_path": mr_change["old_path"],
            "position_type": "text",
            "start_sha": diff_refs["start_sha"],
            "head_sha": diff_refs["head_sha"],
            "base_sha": diff_refs["base_sha"],
        }
        position.update(post_mr_comment_to_line)
        call_gitlab_with_retry(
            post_mr_comment_in_position,
            (PROJECT_ID, MERGE_REQUEST_IID, position, comment),
            {},
        )


def is_deleted_file(change):
    return change.get("deleted_file", False)


def add_mr_description(final_summary, last_description):
    global TOTAL_TOKENS_USED
    global OPENAI_CALLS_DONE

    try:
        [updated_mr_description, tokens_used, openai_calls_done] = call_openai_complete(
            "Based on this "
            + final_summary
            + "Write the Merge Request description by strictly following the given format without removing the details:"  # noqa
            + last_description
            + "Ignore the unknown fields.",
            retries=1,
            sleep_time=0,
        )

        print(f"Updating MR description to: {updated_mr_description}")
        update_mr_description(PROJECT_ID, MERGE_REQUEST_IID, updated_mr_description)

        TOTAL_TOKENS_USED += tokens_used
        OPENAI_CALLS_DONE += openai_calls_done
    except Exception as e:
        print(f"Failed to update MR description. Error: {e}")


def create_summary_comment_for_mr(review_prompts, final_summary):
    if len(review_prompts) > 0:
        pg_link = get_playground_link(random.choice(review_prompts))
    else:
        pg_link = ""

    return (
        f"{TAG_MR_COMMENT}:\n\n{final_summary}"
        + f"\n\nModel used: {OPENAI_MODEL}"
        + f"\n\nOpenAI calls made: {OPENAI_CALLS_DONE}"
        + f"\n\nTotal tokens used: {TOTAL_TOKENS_USED}"
        + "\n\n-----"
        + "\n\n### Think the this review can be improved?"
        + "\n\n_If you want to improve the review you can always update the prompts in the code base and see the changes in the next review."  # noqa
        + " See [here](https://data-experience.pages.agodadev.io/gpt-code-review/configuring_review_prompt.html) for more details._"  # noqa
        + f"\n\nHere's the [GPT Playground link]({pg_link}) for this review if you want to try different prompts or parameters."  # noqa
        if not FF_SKIP_SUMMARY
        else ""
    ) + f"\n\nLatest Review Commit SHA: {COMMIT_SHA}\n"


def post_comment_on_mr(comment):
    print(f"Commenting on MR with comment: {comment}")

    try:
        comment_id = get_mr_comment_id_using_text(
            PROJECT_ID,
            MERGE_REQUEST_IID,
            TAG_MR_COMMENT,
        )

        call_gitlab_with_retry(
            post_mr_comment, (PROJECT_ID, MERGE_REQUEST_IID, comment, comment_id), {}
        )
        return comment_id
    except Exception as e:
        print(f"Failed to summary comment on MR. Error: {e}")


def get_mr_changes():
    mr_comment = get_mr_comment_body_using_text(
        PROJECT_ID,
        MERGE_REQUEST_IID,
        TAG_MR_COMMENT,
    )

    diff = get_mr_diff(PROJECT_ID, MERGE_REQUEST_IID)
    mr_changes = diff["changes"]

    latest_changes = mr_changes
    if mr_comment:
        try:
            latest_review_commit_sha = parse_latest_review_commit(mr_comment)
            if latest_review_commit_sha:
                current_changes = get_diff_from_specific_commit(
                    PROJECT_ID, latest_review_commit_sha, COMMIT_SHA
                )["diffs"]
                file_changes = set({})
                for change in current_changes:
                    file_changes.add(change["new_path"])
                latest_changes = []
                for change in mr_changes:
                    if change["new_path"] in file_changes:
                        latest_changes.append(change)
        except Exception as e:
            print(f"Failed to get changes by commit sha. Error: {e}")

    return (mr_changes, latest_changes)


def parse_latest_review_commit(mr_comment):
    match = re.search(r"Latest Review Commit SHA:\s*(\w+)", mr_comment)

    if match:
        commit_sha = match.group(1)
        return commit_sha

    return None


# Call gitlab with retry if there is any error
def call_gitlab_with_retry(func, args, kwargs, retries=3, wait_time=2):
    for i in range(retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if i == retries - 1:
                raise e
            time.sleep(wait_time)


def send_message_hadoop(comment_id):
    try:
        send_message(
            CodeReviewMessage(
                gitlab_project_id=PROJECT_ID,
                gitlab_project_name=PROJECT_NAME,
                gitlab_merge_request_iid=MERGE_REQUEST_IID,
                gitlab_project_branch=COMMIT_REF_NAME,
                openai_model=OPENAI_MODEL,
                token_usage=TOTAL_TOKENS_USED,
                note_id=comment_id,
                review_type="file-based",
            )
        )
    except Exception as e:
        print(f"Failed to send message to hadoop. Error: {e}")


async def main():
    global TOTAL_TOKENS_USED
    global OPENAI_CALLS_DONE
    mr_details = get_mr(PROJECT_ID, MERGE_REQUEST_IID)
    review_prompt = PROMPT if PROMPT else load_prompt_from_file("file-based.md")
    additional_prompt = get_additional_prompt(mr_details.description)

    if additional_prompt:
        review_prompt = review_prompt + "\n\n" + additional_prompt

    (mr_changes, latest_changes) = get_mr_changes()
    diff_refs = mr_details.diff_refs

    print(f"Diff refs: {diff_refs}")

    print(f"Total changes: {len(latest_changes)} and review prompt: {review_prompt}")

    final_summary = await summary_diffs(mr_changes)
    review_prompts = await process_diffs(diff_refs, latest_changes, review_prompt)

    if FF_UPDATE_MR_DESCRIPTION and final_summary:
        add_mr_description(final_summary, mr_details.description)

    mr_comment = create_summary_comment_for_mr(review_prompts, final_summary)
    comment_id = post_comment_on_mr(mr_comment)

    send_message_hadoop(comment_id)


if __name__ == "__main__":
    if not FF_DISABLE_BLACKLIST_VALIDATION and is_blacklisted_branch():
        print("Skipping review for blacklisted branch")
    else:
        asyncio.run(main())
