import os

import yaml


def main():
    print("Setting up GPT code review for your repository")
    # check if .prompts folder exists
    if os.path.isdir(".prompts"):
        print(".prompts folder already exists")
    else:
        print("Creating .prompts folder")
        os.mkdir(".prompts")

    # check if .prompts/default_prompts folder exists
    if os.path.isdir(".default_prompts"):
        # copy all files from .default_prompts to .prompts
        print("Copying default prompts to .prompts folder")
        for file in os.listdir(".default_prompts"):
            os.system(f"cp .default_prompts/{file} .prompts")

    # Check if .gitlab-ci.yml exists
    if os.path.isfile(".gitlab-ci.yml"):
        print(".gitlab-ci.yml already exists")
        # get the content of .gitlab-ci.yml
        with open(".gitlab-ci.yml", "r") as f:
            content = f.read()
            print("Adding gpt-code-review to .gitlab-ci.yml")
            # read yaml file
            yml = yaml.safe_load(content)

            # get stages
            stages = yml["stages"]

            # get includes
            includes = yml["include"]

            # add gpt-code-review to includes
            includes.append(
                {
                    "project": "data-experience/gpt-code-review",
                    "ref": "main",
                    "file": ["/ci-template/gpt-code-review.gitlab-ci.yml"],
                }
            )

            print("Adding gpt-code-review to stages in .gitlab-ci.yml")
            # add gpt-code-review to stages
            stages.append("gpt-code-review")

            # add gpt-code-review to jobs
            yml["GPT Code Review"] = {
                "stage": "gpt-code-review",
                "extends": ".gpt-code-review",
                "variables": {"FF_UPDATE_MR_DESCRIPTION": "false"},
                "rules": [
                    {"if": "$CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH", "when": "never"},
                    {
                        "if": "$CI_MERGE_REQUEST_IID",
                        "when": "manual",
                        "allow_failure": True,
                    },
                ],
            }

            yml_string = yaml.dump(yml, sort_keys=False, indent=4, width=100)

            # add line breaks bewteen top level keys without using regex
            for key in yml:
                if key != "include" and key != "variables":
                    yml_string = yml_string.replace(key + ":", "\n\n" + key + ":")

            # write to .gitlab-ci.yml
            with open(".gitlab-ci.yml", "w") as f:
                # format yaml file
                f.write(yml_string)


if __name__ == "__main__":
    main()
