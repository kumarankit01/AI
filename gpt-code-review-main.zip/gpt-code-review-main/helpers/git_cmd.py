from git import Repo


def squash_commits(repo_path, branch, num_commits, commit_message):
    repo = Repo(repo_path)
    git = repo.git

    # fetch all remote branches
    git.fetch("--all")

    # checkout the branch we want to squash
    git.checkout(branch)

    # Move the HEAD to the commit before the ones we want to squash
    git.reset("--soft", f"HEAD~{num_commits}")

    # Commit the changes to squash previous commits
    index = repo.index
    index.commit(commit_message)


def git_push(repo_path, force=False):
    repo = Repo(repo_path)
    git = repo.git

    if force:
        print("Force pushing to remote")
        git.push()
    #    git.push("--force")
    else:
        git.push()
