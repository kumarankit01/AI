def get_prompt_summary_per_file():
    return """
    # File Content

    ```
    {file_content}
    ```

    # GIT Diff

    ```
    {diff}
    ```

    ## Instructions

    Please provide a concise summary (up to 100 words) of the code differences,
    specifically emphasizing the changes in the GIT Diff.
    Focus on any alterations to exported function signatures, global data structures, variables,
    and modifications that may affect the external interface or overall behavior of the code.
    """


def get_prompt_group_file_summaries():
    return """Presented below is a chronological list of modifications included in this pull request.
    Each entry contains the filenames and a summary of the associated changes, separated by line breaks.
    The task is to merge and categorize files with similar or related updates into a single entry.
    Provide the restructured list of grouped modifications while preserving the original input format.

    ```
    {raw_summary}
    ```
    """


def get_prompt_final_summary():
    return """Here is the raw summary of changes for the files:
    ```
    {raw_summary}
    ```

    Provide your final response in markdown, with the following sections:

    - ## Overview
    A high-level overview of the overall modifications,
    limited to 80 words instead of detailing changes in individual files.

    - ## Changes
    A markdown table outlining the altered files and their respective summaries.
    Consolidate files with similar adjustments into single rows to conserve space.

    Refrain from further comments since this summary will serve as an annotation on the GitHub pull request.
    Remember to use the headings "Overview" and "Changes" as H2 elements.
    """
