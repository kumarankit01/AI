import re

import gitlab

from helpers.config import GITLAB_API_TOKEN, INCLUDE_FILE_EXTENSIONS

gl = gitlab.Gitlab("https://gitlab.agodadev.io", private_token=GITLAB_API_TOKEN)


# GitLab related functions
def get_mr_diff(project_id, mr_iid):
    project = gl.projects.get(project_id)
    mr = project.mergerequests.get(mr_iid)
    changes = mr.changes()
    changes["changes"] = filter_changes_by_include_file_extensions(changes["changes"])
    return changes


def get_diff_from_specific_commit(project_id, source_commit_sha, target_commit_sha):
    project = gl.projects.get(project_id)
    diffs = project.repository_compare(source_commit_sha, target_commit_sha)
    diffs["diffs"] = filter_changes_by_include_file_extensions(diffs["diffs"])
    return diffs


def filter_changes_by_include_file_extensions(changes):
    if INCLUDE_FILE_EXTENSIONS:
        include_patterns = [
            re.compile(pattern) for pattern in INCLUDE_FILE_EXTENSIONS.split(",")
        ]

        filtered_changes = []
        for change in changes:
            file_path = change["new_path"]
            if any(pattern.match(file_path) for pattern in include_patterns):
                filtered_changes.append(change)
        return filtered_changes

    return changes


# Get file content
def get_file_content(project_id, file_path, ref):
    project = gl.projects.get(project_id)
    file = project.files.get(file_path=file_path, ref=ref)
    file_content_bytes = file.decode()  # This line returns bytes
    file_content = file_content_bytes.decode(
        "utf-8"
    )  # This line converts bytes to string
    return file_content


# Get MR details
def get_mr(project_id, mr_iid):
    project = gl.projects.get(project_id)
    mr = project.mergerequests.get(mr_iid)
    return mr


# Post comment to MR
def post_mr_comment(project_id, mr_iid, comment, comment_id=None):
    project = gl.projects.get(project_id)
    mr = project.mergerequests.get(mr_iid)
    if comment_id:
        mr.notes.update(comment_id, {"body": comment})
    else:
        mr.notes.create({"body": comment})


def post_mr_comment_in_position(project_id, mr_iid, position, comment):
    project = gl.projects.get(project_id)
    mr = project.mergerequests.get(mr_iid)
    mr.discussions.create({"body": comment, "position": position})


def update_comment_to_unresolved(project_id, mr_iid, comment_id):
    project = gl.projects.get(project_id)
    mr = project.mergerequests.get(mr_iid)
    discussions = mr.discussions.list(get_all=True)
    for discussion in discussions:
        if comment_id in [note["id"] for note in discussion.attributes["notes"]]:
            discussion.resolved = False
            discussion.save()
            return


# function to get MR comment ID using text
def get_mr_comment_id_using_text(project_id, mr_iid, comment_text):
    comment = _get_mr_comment_using_text(project_id, mr_iid, comment_text)
    if comment:
        return comment.id
    return None


def get_mr_comment_body_using_text(project_id, mr_iid, comment_text):
    comment = _get_mr_comment_using_text(project_id, mr_iid, comment_text)
    if comment:
        return comment.body
    return None


# update MR description
def update_mr_description(project_id, mr_iid, description):
    project = gl.projects.get(project_id)
    mr = project.mergerequests.get(mr_iid)
    mr.description = description
    mr.save()


def _get_mr_comment_using_text(project_id, mr_iid, comment_text):
    project = gl.projects.get(project_id)
    mr = project.mergerequests.get(mr_iid)
    notes = mr.notes.list(get_all=True)
    for note in notes:
        if comment_text in note.body:
            return note
    return None
