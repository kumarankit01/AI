import os

# Required! Set these in gitlab CI/CD variables
GITLAB_API_TOKEN = os.environ["GITLAB_API_TOKEN"]


OPENAI_API_BASE = "https://chatgpt-proxy.agoda.is"  # pragma: allowlist secret
OPENAI_API_KEY = "sk-ssot-gpt-code-review"  # pragma: allowlist secret

# Optional settings
OPENAI_MODEL = os.environ.get(
    "OPENAI_MODEL", "gpt-4-1106-preview"
)  # pragma: allowlist secret
OPENAI_MODEL_MAX_TOKENS = int(os.environ.get("OPENAI_MODEL_MAX_TOKENS", "120000"))

# CI variables
PROJECT_ID = os.environ["CI_PROJECT_ID"]
MERGE_REQUEST_IID = int(os.environ["CI_MERGE_REQUEST_IID"])
COMMIT_SHA = os.environ["CI_COMMIT_SHA"]
COMMIT_REF_NAME = os.environ["CI_COMMIT_REF_NAME"]
PROJECT_NAME = os.environ["CI_PROJECT_NAME"]
PROJECT_DIR = os.environ["CI_PROJECT_DIR"]
PROMPT = os.environ.get("PROMPT")
INCLUDE_FILE_EXTENSIONS = os.environ.get(
    "INCLUDE_FILE_EXTENSIONS"
)  # optional (CSV of regex, e.g ".+\.ts$,.+\.tsx$")

# Other dependencies
MESSAGING_SERVICE_BASE_URL = os.environ.get(
    "MESSAGING_SERVICE_BASE_URL",
    "http://hkg-gc-be.agoda.local",  # pragma: allowlist secret
)


# TODO: add more branches to blacklist from automated MRs
BLACKLIST_BRANCHES = os.environ.get("BLACKLIST_BRANCHES", "renovate/*").split(",")


# Feature flags
FF_UPDATE_MR_DESCRIPTION = (
    os.environ.get("FF_UPDATE_MR_DESCRIPTION", "false").lower() == "true"
)
FF_DISABLE_BLACKLIST_VALIDATION = (
    os.environ.get("FF_DISABLE_BLACKLIST_VALIDATION", "false").lower() == "true"
)
FF_SKIP_SUMMARY = os.environ.get("FF_SKIP_SUMMARY", "false").lower() == "true"
