from py_messaging_client import BaseMessage, MessageSender, SchemaManager

from helpers.config import MESSAGING_SERVICE_BASE_URL


def send_messages(messages):
    sender = MessageSender("gpt-code-review", base_url=MESSAGING_SERVICE_BASE_URL)
    for message in messages:
        sender.send(message)


def send_message(message):
    print(f"Logging: {message}")
    sender = MessageSender("gpt-code-review", base_url=MESSAGING_SERVICE_BASE_URL)
    sender.send(message)


class CodeReviewMessage(BaseMessage):
    def __init__(
        self,
        gitlab_project_id: int,
        gitlab_project_name: str,
        gitlab_project_branch: str,
        gitlab_merge_request_iid: int,
        openai_model: str,
        token_usage: int,
        note_id: int,
        review_type: str = "whole-diff",
    ):
        pass

    gitlab_project_id = "An integer mapping to gitlab project id"
    gitlab_project_name = "A string mapping to gitlab project name"
    gitlab_project_branch = "A string mapping to gitlab project branch"
    gitlab_merge_request_iid = "An integer mapping to gitlab merge request iid"
    openai_model = "A string mapping to openai model"
    token_usage = "An integer mapping to token usage"
    note_id = "An integer mapping to gitlab note id"
    review_type = "A string mapping to review type"

    def __repr__(self) -> str:
        return f"{self.gitlab_project_name} {self.gitlab_project_branch}, {self.openai_model}, {self.token_usage}"


def register_schema() -> None:
    schema_manager = SchemaManager("http://hk-schemaregistry.agoda.local:8081")

    compatibility_res = schema_manager.check_compatibility(CodeReviewMessage)
    assert (
        compatibility_res.is_compatible
    ), f"Schema is not valid or is not compatible with existing schema: {compatibility_res.compatibility_message}"

    schema_id = schema_manager.register_schema("gpt-code-review", CodeReviewMessage)
    print(f"Registered schema ID: {schema_id}")
