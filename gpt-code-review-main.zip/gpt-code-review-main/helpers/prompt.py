import os
import re

from helpers.config import PROJECT_DIR


# Function to get default prompt directory
def get_prompt_file_path(file_path):
    # Will be used when the codebase does not have .prompts folder
    fallback_dir = ".default_prompts"
    # check for .prompts folder in the root of the project
    if os.path.isdir(os.path.join(PROJECT_DIR, ".prompts")):
        if os.path.isfile(os.path.join(PROJECT_DIR, ".prompts", file_path)):
            return os.path.join(PROJECT_DIR, ".prompts", file_path)

    return os.path.join(fallback_dir, file_path)


# Get prompt from file
# If the file is not found in .prompts folder, it will look for it in .default_prompts folder
def load_prompt_from_file(file_path):
    prompt_file_path = get_prompt_file_path(file_path)
    print(f"Loading prompt from {prompt_file_path}")
    with open(prompt_file_path, "r") as f:
        prompt = f.read()
    return prompt


# Get Override prompt from MR description it's a code block with the following format:
# ```prompt
# <prompt>
# ```
def get_additional_prompt(description):
    matches = re.findall(r"```prompt(.*?)```", description, re.DOTALL)

    if matches:
        return matches[0].strip()
    else:
        return ""
