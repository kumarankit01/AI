import re

from helpers.config import BLACKLIST_BRANCHES, COMMIT_REF_NAME


def is_blacklisted_branch(branch_name=COMMIT_REF_NAME):
    print(f"Checking if branch {branch_name} is blacklisted")
    return any(
        re.match(blacklisted_branch, branch_name)
        for blacklisted_branch in BLACKLIST_BRANCHES
    )
