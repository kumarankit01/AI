import re


def parse_unified_diff(diff):
    # Split the diff into lines
    lines = diff.split("\n")

    # Define the regular expression to find the diff metadata
    line_number_pattern = re.compile(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")

    parsed_diff = []
    current_old_line, current_new_line = None, None
    for line in lines:
        match = line_number_pattern.search(line)

        # If the pattern matched, we found a new chunk
        if match:
            current_old_line = int(match.group(1))
            current_new_line = int(match.group(2))

        # Process removed line
        elif line.startswith("-"):
            line_info = {
                "content": line[1:],
                "old_line": current_old_line,
                "new_line": None,
                "status": "removed",
            }

            # Check if the removed line is part of a removed chunk
            if parsed_diff and parsed_diff[-1]["old_line"] == current_old_line - 1:
                prev_line_info = parsed_diff[-1]
                prev_line_info["old_line"] = current_old_line
                prev_line_info["content"] += " | " + line_info["content"]

            # If not corresponds, it's start of a new removed chunk
            else:
                parsed_diff.append(line_info)

            current_old_line += 1

        # Process added line
        elif line.startswith("+"):
            line_info = {
                "content": line[1:],
                "old_line": None,
                "new_line": current_new_line,
                "status": "added",
            }

            # Check if the added line corresponds to the previous removed line (i.e., update)
            if parsed_diff and parsed_diff[-1]["old_line"] == current_new_line - 1:
                prev_line_info = parsed_diff[-1]
                prev_line_info["new_line"] = current_new_line
                prev_line_info["status"] = "updated"
                prev_line_info["content"] += " | " + line_info["content"]

            # Check if the added line is part of an added chunk
            elif parsed_diff and parsed_diff[-1]["new_line"] == current_new_line - 1:
                prev_line_info = parsed_diff[-1]
                prev_line_info["new_line"] = current_new_line
                prev_line_info["content"] += " | " + line_info["content"]

            # If not corresponds, it's start of a new added chunk
            else:
                parsed_diff.append(line_info)

            current_new_line += 1

        elif current_new_line is not None and current_old_line is not None:
            current_old_line += 1
            current_new_line += 1

    return parsed_diff
