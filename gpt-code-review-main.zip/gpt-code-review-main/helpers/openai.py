import json
import time

import openai
import requests

from helpers.config import OPENAI_API_BASE, OPENAI_API_KEY, OPENAI_MODEL

openai.api_key = OPENAI_API_KEY  # pragma: allowlist secret
openai.api_base = OPENAI_API_BASE


# Retry settings
RETRIES = 1
SLEEP_TIME = 5

# OpenAI model settings: https://platform.openai.com/docs/api-reference/chat/create
MAX_RESPONSE_TOKENS = 2048  # Max 4096
TEMPERATURE = 0
FREQUENCY_PENALTY = 0.5
REQUEST_TIMEOUT = 600


system_message = {
    "role": "system",
    "content": "You are an extremely proficient software developer/architect. Reviewing a merge request by your fellow colleague.",  # noqa: E501
}


def fallback_handler(prompt, exception):
    raise exception


def call_openai_complete(
    prompt, model=OPENAI_MODEL, retries=RETRIES, sleep_time=SLEEP_TIME
):
    TOTAL_TOKENS_USED = 0
    OPENAI_CALLS_DONE = 0
    for i in range(retries):
        try:
            response = openai.ChatCompletion.create(
                model=model,
                messages=[
                    system_message,
                    {"role": "user", "content": prompt},
                ],
                max_tokens=MAX_RESPONSE_TOKENS,
                temperature=TEMPERATURE,
                frequency_penalty=FREQUENCY_PENALTY,
                request_timeout=REQUEST_TIMEOUT,
            )
            TOTAL_TOKENS_USED += int(response.usage.total_tokens)
            OPENAI_CALLS_DONE += 1
            return [
                response.choices[0].message.content.strip(),
                TOTAL_TOKENS_USED,
                OPENAI_CALLS_DONE,
            ]
        except Exception as e:
            if i == retries - 1:
                return fallback_handler(prompt, e)
            print(
                f"Attempt {i + 1} failed. Error: {e}. Retrying in {sleep_time} seconds..."
            )
            time.sleep(sleep_time)


def get_playground_link(
    prompt,
    model=OPENAI_MODEL,
):
    data = dict(
        model=model,
        messages=[
            system_message,
            {"role": "user", "content": prompt},
        ],
        max_tokens=MAX_RESPONSE_TOKENS,
        temperature=TEMPERATURE,
        frequency_penalty=FREQUENCY_PENALTY,
        request_timeout=REQUEST_TIMEOUT,
    )

    playground_link = None

    try:
        headers = {"Content-Type": "application/json"}
        response = requests.post(
            "https://gpt-playground.agodadev.io/api/generate-link",
            data=json.dumps(data),
            headers=headers,
        )

        if response.status_code != 200:
            print(
                f"Error in getting playground link. Status code: {response.status_code}. Response: {response.text}"
            )
        else:
            playground_link = response.text

        return playground_link
    except Exception as e:
        print(f"Error in getting playground link. Error: {e}")
        return playground_link
