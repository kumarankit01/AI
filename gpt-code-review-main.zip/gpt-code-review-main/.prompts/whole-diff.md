Do the following:

Summarize the code changes in an easy to understand way and highlighting the important changes.
Highlight if the code is not following standard coding guidelines and lint specific to the language.
Highlight if the code is difficult to understand and suggest ways to improve it.
Highlight if there are any performance improvements possible.
Highlight if there are any other issues with the code, along with possible fixes.
Highlight if the code is not following these project specific principles as well:

End of instructions.
